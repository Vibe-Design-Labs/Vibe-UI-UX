# IntentKit / 意译

把日常设计表达转成专业 UI/UX 术语、可操作演示和准确描述。v0.3 提供纸张与手写字风格的官网、工作台、25 个词条、16 个可控演示模板、五语界面和 TokenDance BYOK。

[在线体验](https://vibe-design-labs.github.io/Vibe-UI-UX/) · [GitHub 开源仓库](https://github.com/Vibe-Design-Labs/Vibe-UI-UX) · [GitHub Pages / Fork 部署](docs/GITHUB_PAGES.md) · [维护新内容](docs/CONTENT_MAINTENANCE.md) · [字体与许可](docs/FONTS.md) · [TokenDance 接入](docs/TOKENDANCE.md) · [叶片与聚光](docs/LEAF_CURSOR.md) · [更新记录](CHANGELOG.md)

![IntentKit 米纸与手写字风格界面](docs/preview.png)

IntentKit translates everyday design intentions into professional UI/UX vocabulary, live previews and reusable design briefs. Bring your own TokenDance key for optional AI suggestions. The interface supports Chinese, English, Japanese, Korean and German. Basic search, previews, parameter tuning and export work without an API key. Fork-friendly static deployment on GitHub Pages is included; visitors connect directly to TokenDance from their browser with their own key. No shared model key or backend is required for Pages. Application code is MIT; bundled fonts remain under SIL OFL 1.1.

## 当前版本：0.4.0.1.0

官网加入墨绿叶片指针、米色叶脉、朱砂墨点和暖杏金聚光。工作台可独立调整指针与灯光的跟随、颜色、半径和透明度；预览与 JSON 导出使用同一组参数。输入、弹窗、触摸、键盘和减少动态效果保留原生操作。

公开版本采用五段编号，由 package.json 的 intentkitVersion 统一管理。网页显示、version.json、更新记录与 Git 标签保持完整编号；package.json 的 version 保留 npm 兼容格式，当前为 0.4.1。详见 [版本规则](docs/VERSIONING.md)。

## 运行

Node.js 20+，无需 npm 依赖。Python 3 用于内容验证与源码打包。

    npm run dev
    # http://localhost:4173
    npm run build
    npm test
    npm run check:content

修改源码后重新启动本地服务以加载新构建。本地启动、浏览、预览、复制、导出与内容更新不调用模型。只有配置密钥并点击工作台“查找效果”才会产生 TokenDance 请求与可能的费用。

## 架构

- public/index.html：静态官网，米纸色、墨灰、苔绿与朱砂红；错落纸页、交互演示、滚动入场与按钮吸附。
- public/studio.html：搜索、筛选、候选比较、参数、描述与 JSON 导出。
- content/items/*.json：一词条一文件，稳定 ID、双语正文、别名、来源与审校状态。
- previews/registry.json：参数默认值、合法范围、枚举。
- public/previews.js：受控渲染器，不运行模型生成代码。
- public/leaf-art.js：已确认叶片稿的矢量实现；构建时生成同源 leaf-cursor.svg。
- public/brand-pointer.js / pointer-light.js：首页品牌指针、聚光、取消与原生操作恢复。
- public/core.js：最终参数校验、描述生成与候选校验；预览与导出共用。
- public/i18n.js：中文、英文、日文、韩文、德文界面；content 翻译独立维护。
- public/polish.css：纸张配色、字体、字号与响应式布局；public/fonts/ 自托管 OFL 字体。
- public/tokendance.js：模型协议筛选、S256 PKCE、授权交换、错误恢复与共享提示词。
- public/connection.js：实时模型列表、授权弹窗、手动 BYOK；密钥和 PKCE 验证信息仅在内存。
- public/authorize.html：静态授权回调，同源窗口、来源与流程标识校验。
- server/worker.js：固定 TokenDance 地址的模型目录、授权交换与对话中转。
- scripts/build.mjs：生成本地/Worker 模式的 dist/client 与 dist/server/index.js。
- scripts/build-pages.mjs：生成 dist/pages/，采用相对路径和浏览器直连 BYOK。
- .github/workflows/pages.yml：main 推送或手动触发时验证并自动部署 GitHub Pages。
- skills/ui-ux-content-maintainer：可交给其他 AI 使用的维护 skill 与本地检查脚本。

## 维护新内容

把维护 skill 和本 README 交给任意支持读写文件的 AI。选择已注册模板时，只需新增或编辑 content/items/*.json。新模板才需要同时更新注册表、渲染器、界面语言文案与验证。

    python skills/ui-ux-content-maintainer/scripts/validate_content.py .

内容发布审校后运行：

    python skills/ui-ux-content-maintainer/scripts/validate_content.py . --publish-check --require-locales zh-CN en

检查器不联网、不使用 API Key、不消耗 GPT 模型额度。使用其他 AI 本身可能有其服务费用。

词条以中英文草稿为主；新加入的自定义光标提供五语草稿，其余日/韩/德正文明确英文回退。五语“界面完整”与五语“内容完整”是不同状态。严格发布检查目前应失败，避免把草稿当作已审校知识库。seed-content.py 是一次性初始作者脚本，后续维护不要重新运行，以免覆盖已编辑词条。

## 动效与可访问性

首页叶片精确跟随点击位置，灯光单独平滑跟随。默认指针 32px，聚光半径 160px、透明度 0.15、颜色 #EBCB8B、灯光时间常数 80ms。叶片 SVG 尖端为热区，悬停轻微放大、点击出现朱砂小圆环。输入与弹窗恢复原生指针，触摸和减少动态效果不启动指针或灯光跟随。

鼠标聚光通过 pointermove、requestAnimationFrame 和径向渐变实现；模板使用同一份半径、透明度、抬升距离和过渡时长。鼠标吸附仅用于官网主要操作。粗指针触摸不启动指针跟随；保留原生光标和原生控件。

尊重 prefers-reduced-motion，关闭非必要位移、扫光、装饰循环与鼠标跟随。官网提供暂停装饰动效按钮。键盘焦点可见、模态支持 Escape、候选和状态消息可操作。WebMCP 仅在 document.modelContext 存在时注册两个无模型调用的工具：search_design_terms 与 set_design_preview。

## GitHub Pages 与 fork

推荐将项目发布到自己的 GitHub Pages。完整操作见 [Pages 指南](docs/GITHUB_PAGES.md)：提交源码到 main，在 Settings → Pages 选择 GitHub Actions，然后运行 Deploy GitHub Pages 工作流。fork 后在自己的仓库完成同样的一次性设置即可；相对路径无需改用户名或仓库名前缀。后续 main 更新自动部署。

    python scripts/package-source.py
    npm run build:pages
    npm run preview:pages
    # http://localhost:4174/Vibe-UI-UX/

构建输出为 dist/pages/，只有静态 HTML/CSS/JS/JSON/字体/源码下载包。也可以将它部署到其他静态主机。源码包包含 .github 工作流，排除 .git、托管身份、环境文件、node_modules 和 dist。项目已于 2026-10-04 转移至 Vibe-Design-Labs 组织，Pages 使用 GitHub Actions 部署：[打开网站](https://vibe-design-labs.github.io/Vibe-UI-UX/)。fork 后在自己的仓库启用 Pages，网址以自己的部署输出为准。

## BYOK 隐私和限制

静态 Pages 版由浏览器直连固定 https://tokendance.space/gateway/v1/chat/completions。连接面板读取实时公开模型目录，只列出 supported_protocols 含 openai:chat-completions 的模型；读取失败可手动填写官方模型 ID。支持通过 TokenDance 授权弹窗（S256 PKCE）创建新 Key，也支持手动输入已有 Key。访客自己的密钥仅在当前页面内存，通过 Authorization 发送到 TokenDance，不放在仓库、构建产物或 GitHub Secrets 中。刷新或清除后丢弃，不写 localStorage/sessionStorage、数据库或日志。只有界面语言偏好会保存至 localStorage。

2026-10-06 依据 [官方接入文档](https://tokendance.space/docs/ai-integration.md) 更新。实测公开模型目录 HTTP 200，108 个模型中有 71 个支持对话协议；Chat Completions 与授权交换 OPTIONS 均返回 204。公开目录读取及授权交换不调用模型；授权会在用户确认后创建 Key。尚未使用真实模型密钥进行付费联调；实际额度、模型可用性及未来跨域策略需实际接入时确认。网络或跨域失败时显示可理解的错误，清除密钥后可继续本地查询。

本地 npm run dev 与可选 Cloudflare Worker 版本保留同源中转方式；当前实例会接触访客的密钥，应仅在可信部署使用。静态版不依赖这个服务器。两种方式都将实际部署的稳定 App URL 用于 OAuth app_url 与调用 X-App-URL（本机使用 app://intentkit）。错误仅保留已知恢复动作，提示充值、重新授权或等待周期刷新，不自动充值或重试。两种方式都只接受已知候选 ID、限制输入和返回大小、禁止上游重定向；模型输出作为文本显示，不执行生成的任意代码。

日常内容更新、构建、检查、GitHub Pages 部署不会调用模型，不消耗 GPT 或 TokenDance 模型额度。使用者自行选择模型并承担调用费用。

早期交互方向参考 https://www.hyperknow.io/；v0.3 根据用户提供的米纸、水墨、朱砂与手写字体参考重新设计。原创编排与代码，不使用参考站或参考图片的图片、商标、正文或组件源码。知识来源链接在各词条数据中；解释与演示为本项目原创。

## Typography & licenses

标题采用 Ma Shan Zheng 的改名 Web 子集，正文采用 LXGW WenKai 的改名 Web 子集，英文手写采用 Caveat。参考图未写明实际字体名称，不宣称与参考图为同款。字形来源、作者版权、三个完整 OFL 许可与无 AI 调用的子集重建步骤见 [字体说明](docs/FONTS.md)。新增未收录字符时，重新运行子集脚本；平时运行网站不需要安装字体制作依赖。
